#define true 1
#define false 0

typedef int mybool;

