#include <stdbool.h>
#include <assert.h>

#include "fixstring.h"

unsigned int fstring_length(fixstring s) {
    unsigned int posicion=0;
    while (s[posicion] != '\0'){
        posicion++;
    }
    return posicion;
}
 
bool fstring_eq(fixstring s1, fixstring s2) {
    bool veracidad = true;
    int posicionamiento = 0; 
    
    if (fstring_length(s1) != fstring_length(s2))
    {
        veracidad = false;
    }
    
    while (veracidad == true && (s1[posicionamiento] != '\0') && (s2[posicionamiento] != '\0') )
    {
        if (s1[posicionamiento] != s2[posicionamiento])
        {
            veracidad = false; 
        }
        posicionamiento = posicionamiento + 1;
    }
    
    return veracidad;
}

 bool fstring_less_eq(fixstring s1, fixstring s2) {
    bool veracidad = true;

    for (unsigned int posicionamiento = 0; s1[posicionamiento] !='\0' || s2[posicionamiento] != '\0'; posicionamiento++)
    {
        if (s1[posicionamiento] < s2[posicionamiento])
        {
            veracidad = false;
        }
        
    }
    return veracidad;
 }

