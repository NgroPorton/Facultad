#include <stdio.h>
// Función para verificar si un número es primo
int esPrimo(int numero) {
    if (numero <= 1) {
        return 0;
    }
    for (int i = 2; i * i <= numero; i++) {
        if (numero % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main() {
    int n;
    printf("Ingrese el valor de n: ");
    scanf("%d", &n);

    int contador = 0;
    int i = 2; // Empezamos con el primer número primo, que es 2

    while (contador < n) {
        if (esPrimo(i)) {
            contador++;
            if (contador == n) {
                printf("El %d-ésimo número primo es: %d\n", n, i);
            }
        }
        i++;
    }

    return 0;
}