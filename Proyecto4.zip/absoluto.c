#include <stdio.h>
#include <assert.h>

int pedir_entero(char name)
{
    int n;
    printf("ingresar valor para %c \n", name);
    scanf("%d", &n);
    return (n);

}

int main(void)
{
    int x;
    x = pedir_entero ('x');
    
    if (x <= 0){
        x = x *(-1);
        printf("%d\n", x);
        assert(x <= 0);
    } else if(x>0){
        x = x;
        printf("%d\n", x);
        assert(x>0);
    }
    return(0);
    
}