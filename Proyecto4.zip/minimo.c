#include <stdio.h>
#include <assert.h>

int pedir_entero(char name)
{
    int n;
    printf("ingresar valor para %c \n", name);
    scanf("%d", &n);
    return (n);

}


int main (void)
{ 
    int x, y;
    x = pedir_entero ('x');
    y = pedir_entero ('y');
        if (x < y){
        printf("el minimo es %d \n",x);
        assert(x < y);
    } else if (x > y){
        assert(x > y);
        printf ("el minimo es %d \n",y);
    }

    return (0);
}