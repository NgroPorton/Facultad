#include <stdio.h>
#include <assert.h>
#include <stdbool.h>

int pedir_entero(char name)
{
    int x;
    printf("Valor para entero para almacenar %c \n",(name));
    scanf("%d", &x);
    return x; 

}

bool es_primo (int N){

    if (N == 1 || N == 2)
    {
        return(1);
    }else if (N == 0){
        return(0);
    }

    int i = 2;
    while ( N > i)
    {
        if (N % i == 0)
        {
            return(0);
        }

        i = i + 1; 
    }
    

    return(1);
}

int nesimo_primo(int N)
{
    int c, i;
    c = 0;
    i = 2;
    while (N > c)
    {
        if (es_primo(i))
        {
            c = c + 1;
        }
        i = i + 1;
    }
    
    return(i - 1);
}

int main (void)
{
    int n;
    n = pedir_entero('n');
    printf("El %d-nesimo primo es %d\n",n,nesimo_primo(n));
    return (0);
}

